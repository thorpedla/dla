from TwitterSearch import *
import random
import spacy
	

name = input("Hi there! What's your name?")
email = input("Great to meet you! I'm a simple bot that was made to get to know people. My purpose in life is to help you stay connected with the people in your life. Please tell me your e-mail.")
birthday = input("When's your birthday?")
work = input("What is your occupation?")
school = input('Where do/did you go to school? ')
movie = input('What is your favorite movie? ')
tv_show = input('What is your favorite TV show? ')
music = input('Who is your favorite musical artist? ')
song = input('What is the last song you listened to? ')
event = input('What is the last event you went to? ')
guests = input("Who did you go with?")
last_purchase = input("What's the last thing you purchased online? ")
almost_bought = input("What's the last thing you really wanted to purchase but didn't?")
google = input('What is your last google search? Remember be honest. ')
last_message = input("What is your relationship to the last person you messaged?")
friends = input('What is the name of the person you feel closest to?')
what_up = input("What's happening? 250 words or less")





l = {}
l[work] = "work"
l[movie] = "movie"
l[tv_show] = "tv_show"
l[music] = "music"
l[song] = "song"
l[event] = "event"
l[guests] = "guests"
l[last_purchase] = "last_purchase"
l[almost_bought] = "last_almost_purchase"
l[google] = "google"
l[last_message] = "last_message"
l[friends] = "friends"
l[what_up] = "what up"

keywords = []
for i in range(2):
	i_key = random.choice(list(l.keys()))
	keywords.append(i_key)

words = {}
try:
	nlp = spacy.load('en')
	tso = TwitterSearchOrder()

	

	tso.set_keywords(keywords)
	ts = TwitterSearch(
		consumer_key = '5FwpXj7xujgqP02ZqvtYoIVIE',
	    consumer_secret = 'KdaHgnBchGmikXQQhmUAjyviacGJwxFZSzP9wrUf5krXz9Y44g',
	    access_token = '1400705174-2NXJC1zz5h8tCVGV4hAp521EhJstrEMCBNkKZKh',
	    access_token_secret = 'lXwDernZ1UHZ4BJEmp7IrK6UNygve9SPgV5kr8fqJ5qqT'
	)
	while(len(words)) == 0:
		keywords = []
		for i in range(2):
			i_key = random.choice(list(l.keys()))
			keywords.append(i_key)
		counter = 0 
		for tweet in ts.search_tweets_iterable(tso):
			if counter < 3:
				#print('@%s tweeted: %s' % (tweet['user']['screen_name'], tweet['text']))
				text = tweet['text']
				doc = nlp(text)

				for token in doc:
					if token.pos_ in words:
					 	words[token.pos_].append(token.text)
					else:
					 	words[token.pos_] = [token.text]
				counter+=1
			else:
				break
except TwitterSearchException as e: 
	print(e)

for key in keywords:
	if key == movie and 'VERB' in words:
		verb = random.choice(words['VERB'])
		print("I really loved", movie, ". I " , verb, "everytime." )
	elif key == song and 'ADJ' in words and 'VERB' in words:
		adj = random.choice(words['ADJ'])
		verb = random.choice(words['VERB'])
		print(song, "is such a", adj, "song. Anyone want to", verb, "with me?")
	elif key == tv_show or key == event and 'ADJ' in words:
		adj = random.choice(words['ADJ'])
		print("I really wanted to watch an episode of ", tv_show, "but instead I went to this", adj, event, "with", guests, ".")
	elif key == google:
		print("Anyone know ", google, ". I asked my ", friends, "and they didn't know.")
	elif key == last_purchase or key == almost_bought and 'ADJ' in words:
		adj = random.choice(words['ADJ'])
		print("Should i buy", almost_bought, "? I almost did but I heard that it is", adj , "Also. I just got the " , last_purchase)
	else:
		print(what_up)

