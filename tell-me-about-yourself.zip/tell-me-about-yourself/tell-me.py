from flask import Flask
from flask import request
from flask import render_template
import stringComparison

app = Flask(__name__)

@app.route('/')
def my_form():
    return render_template("sample.html") # this should be the name of your html file

@app.route('/', methods=['POST'])
def my_form_post():
    text1 = request.form['name']
    #text2 = request.form['text2']
  	return text1 #"<h1>Plagiarism Detected !</h1>"
    

if __name__ == '__main__':
    app.run()